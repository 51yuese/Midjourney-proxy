
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as l,o as a,c as i,b as n}from"../main-31e47da4.js";const d={class:"flex-main"};const s=l({},[["render",function(l,s){return a(),i("div",d,s[0]||(s[0]=[n("div",{class:"main-box"},[n("div",null,[n("img",{src:"/gomaxai/admin/static/jpg/bg-b4cb4e98.jpg",alt:""})]),n("div",null,[n("div",null,"室内装修风格"),n("div",null,[n("div",null,"ID：123456"),n("div",null,"复制")]),n("div",null,"小工具说明：这是一个小工具，用于展示装修风格")])],-1)]))}],["__scopeId","data-v-4750bdc5"]]);export{s as default};
