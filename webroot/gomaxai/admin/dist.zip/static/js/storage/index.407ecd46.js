
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import e from"./tencent.8c5738e7.js";import t from"./ali.13d0e82e.js";import i from"./chevereto.890ad7a5.js";import{d as l,r as a,o as s,c as o,b as v,G as d,f as n,J as r,_ as c}from"../main-31e47da4.js";const p={style:{display:"flex","align-items":"center","margin-bottom":"16px"}},u={key:0},_={key:1},m={key:2},f=c(l({__name:"index",setup(l){const c=a(0);function f(e){c.value=e}return(l,a)=>(s(),o("div",null,[v("div",null,[v("div",p,[v("div",{class:d(0==c.value?"type_title":"def_type_title"),onClick:a[0]||(a[0]=e=>f(0))},"腾讯云COS",2),v("div",{class:d(1==c.value?"type_title":"def_type_title"),onClick:a[1]||(a[1]=e=>f(1))},"阿里云OSS",2),v("div",{class:d(2==c.value?"type_title":"def_type_title"),onClick:a[2]||(a[2]=e=>f(2))},"chevereto图床",2)])]),v("div",null,[0==c.value?(s(),o("div",u,[n(e)])):r("",!0),1==c.value?(s(),o("div",_,[n(t)])):r("",!0),2==c.value?(s(),o("div",m,[n(i)])):r("",!0)])]))}}),[["__scopeId","data-v-87317a9f"]]);export{f as default};
