
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import e from"./tencent.9cfd3d82.js";import t from"./ali.771f8fc4.js";import i from"./chevereto.ff8f98b4.js";import{d as l,r as a,o as s,c as o,b as v,G as d,f as n,J as c,_ as r}from"../main-c47e4581.js";const p={style:{display:"flex","align-items":"center","margin-bottom":"16px"}},u={key:0},_={key:1},m={key:2},f=r(l({__name:"index",setup(l){const r=a(0);function f(e){r.value=e}return(l,a)=>(s(),o("div",null,[v("div",null,[v("div",p,[v("div",{class:d(0==r.value?"type_title":"def_type_title"),onClick:a[0]||(a[0]=e=>f(0))},"腾讯云COS",2),v("div",{class:d(1==r.value?"type_title":"def_type_title"),onClick:a[1]||(a[1]=e=>f(1))},"阿里云OSS",2),v("div",{class:d(2==r.value?"type_title":"def_type_title"),onClick:a[2]||(a[2]=e=>f(2))},"chevereto图床",2)])]),v("div",null,[0==r.value?(s(),o("div",u,[n(e)])):c("",!0),1==r.value?(s(),o("div",_,[n(t)])):c("",!0),2==r.value?(s(),o("div",m,[n(i)])):c("",!0)])]))}}),[["__scopeId","data-v-775ec094"]]);export{f as default};
