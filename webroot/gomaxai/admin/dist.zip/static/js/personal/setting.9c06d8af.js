
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as s}from"../index/index.74198fad.js";import{d as a,k as t,r as e,j as l,o as n,c as i,f as o,g as c,b as d,h as r,_ as u,n as p}from"../main-31e47da4.js";const f={class:"setting-list"},m={class:"item"},v={class:"action"},_=a({name:"PersonalSetting"}),b=a({..._,setup(a){const u=t();function p(){u.push({name:"personalEditPassword"})}return e({headimg:"",mobile:"",name:"",qq:"",wechat:""}),(a,t)=>{const e=l("el-button"),u=l("el-tab-pane"),_=l("el-tabs"),b=s;return n(),i("div",null,[o(b,null,{default:c((()=>[o(_,{"tab-position":"left",style:{height:"600px"}},{default:c((()=>[o(u,{label:"安全设置",class:"security"},{default:c((()=>[t[2]||(t[2]=d("h2",null,"安全设置",-1)),d("div",f,[d("div",m,[t[1]||(t[1]=d("div",{class:"content"},[d("div",{class:"title"}," 账户密码 "),d("div",{class:"desc"}," 当前密码强度：强 ")],-1)),d("div",v,[o(e,{type:"primary",plain:"",onClick:p},{default:c((()=>t[0]||(t[0]=[r(" 修改 ")]))),_:1})])])])])),_:1})])),_:1})])),_:1})])}}});"function"==typeof p&&p(b);const h=u(b,[["__scopeId","data-v-06cad3a3"]]);export{h as default};
