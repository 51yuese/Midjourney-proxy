
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as s}from"../permission.vue_vue_type_script_setup_true_lang/permission.vue_vue_type_script_setup_true_lang.cf187dfd.js";import"../main-31e47da4.js";import"../access/access.7995b835.js";export{s as default};
