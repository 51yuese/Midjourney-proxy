
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as i,r as e,E as a,q as c,o as s,c as r,b as l,h as o,t,e as p,J as n,Q as m,_ as g}from"../main-31e47da4.js";const y={class:"copy-container"},u={style:{color:"#9FA3B8"}},h={key:0},b=["href"],N={key:1},d=["href"],f=i({name:"Copyright"}),F=g(i({...f,setup(i){e({copyrightTitle:"GoMaxAiAdmin",copyrightUrl:"/"});const g=a({agreementTitle:"",policyTitle:"",filingNumber:"",companyName:""});return c((()=>{!async function(){const i=await m.copyright({keys:["copyrightTitle","icpNumber","policeFilingNumber","icpUrl","policeFilingUrl"]});i.success&&Object.assign(g,i.data)}()})),(i,e)=>(s(),r("div",y,[l("div",u,[l("p",null,[o("版权所有 © "+t(p(g).copyrightTitle)+" ",1),p(g).icpNumber?(s(),r("span",h,[l("a",{href:p(g).icpUrl||"#"},t(p(g).icpNumber),9,b)])):n("",!0),p(g).policeFilingNumber?(s(),r("span",N,[l("a",{href:p(g).policeFilingUrl||"#"},t(p(g).policeFilingNumber),9,d)])):n("",!0)])])]))}}),[["__scopeId","data-v-0721b57c"]]);export{F as _};
