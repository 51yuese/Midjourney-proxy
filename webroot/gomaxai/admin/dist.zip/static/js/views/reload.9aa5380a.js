
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as a,k as s,q as o,o as t,c as n,n as e}from"../main-31e47da4.js";const r=a({__name:"reload",setup(a){const e=s();return o((()=>{e.go(-1)})),(a,s)=>(t(),n("div"))}});"function"==typeof e&&e(r);export{r as default};
