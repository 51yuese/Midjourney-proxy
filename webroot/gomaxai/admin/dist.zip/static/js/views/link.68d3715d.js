
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as a}from"../index/index.74198fad.js";import{d as n,i as s,j as e,o as i,c as t,f as l,g as o,I as d,b as c,t as r,e as m,h as u,T as p,s as k,_ as f}from"../main-31e47da4.js";const _={class:"link-view"},v={class:"container"},w={class:"link"},b=n({name:"LinkView"}),j=f(n({...b,setup(n){const f=s();function b(){window.open(f.meta.link,"_blank")}return(n,s)=>{const j=k,x=e("el-icon"),y=e("el-button"),I=a;return i(),t("div",_,[l(p,{name:"link",mode:"out-in",appear:""},{default:o((()=>[(i(),d(I,{key:m(f).meta.link,title:"⚠️访问提醒"},{default:o((()=>[c("div",v,[s[1]||(s[1]=c("div",{class:"title"}," 是否访问此链接 ",-1)),c("div",w,r(m(f).meta.link),1),l(y,{type:"primary",plain:"",round:"",onClick:b},{icon:o((()=>[l(x,null,{default:o((()=>[l(j,{name:"ep:link"})])),_:1})])),default:o((()=>[s[0]||(s[0]=u(" 立即访问 "))])),_:1})])])),_:1}))])),_:1})])}}}),[["__scopeId","data-v-721d0a4d"]]);export{j as default};
