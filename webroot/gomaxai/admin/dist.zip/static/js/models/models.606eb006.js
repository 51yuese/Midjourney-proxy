
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{ao as e}from"../main-c47e4581.js";const o={queryModels:o=>e.get("models/query",{params:o}),setModels:o=>e.post("models/setModel",o),delModels:o=>e.post("models/delModel",o)};export{o as A};
