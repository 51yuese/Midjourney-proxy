
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as e,a,z as s,j as n,o as i,I as t,g as l,e as o,c as d,f as m,b as u,Y as c,X as r,J as v,T as b,G as f,t as g,s as p,_ as M}from"../main-31e47da4.js";import h from"../Logo/index.17b9992e.js";import{u as k}from"../useMenu/useMenu.af3dc465.js";const _={key:0,class:"main-sidebar-container"},j={class:"nav"},y=["title","onClick"],w=e({name:"MainSidebar"}),x=M(e({...w,setup(e){const M=a(),w=s(),{switchTo:x}=k();return(e,a)=>{const s=p,k=n("el-icon");return i(),t(b,{name:"main-sidebar"},{default:l((()=>["side"===o(M).settings.menu.menuMode||"mobile"===o(M).mode&&"single"!==o(M).settings.menu.menuMode?(i(),d("div",_,[m(h,{"show-title":!1,class:"sidebar-logo"}),u("div",j,[(i(!0),d(c,null,r(o(w).allMenus,((e,a)=>{var n,r,b;return i(),d(c,null,[e.children&&0!==e.children.length?(i(),d("div",{key:a,class:f(["item",{active:a===o(w).actived}]),title:(null==(n=e.meta)?void 0:n.title)??"[ 无标题 ]",onClick:e=>o(x)(a)},[(null==(r=e.meta)?void 0:r.icon)?(i(),t(k,{key:0},{default:l((()=>[m(s,{name:e.meta.icon},null,8,["name"])])),_:2},1024)):v("",!0),u("span",null,g((null==(b=e.meta)?void 0:b.title)??"[ 无标题 ]"),1)],10,y)):v("",!0)],64)})),256))])])):v("",!0)])),_:1})}}}),[["__scopeId","data-v-79c2b4c4"]]);export{x as default};
