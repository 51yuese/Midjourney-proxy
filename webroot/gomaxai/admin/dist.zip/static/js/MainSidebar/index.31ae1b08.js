
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as e,a,z as s,j as n,o as i,I as t,g as l,e as o,c as d,f as m,b as u,Y as c,X as r,J as v,T as f,G as g,t as p,s as b,_ as M}from"../main-c47e4581.js";import h from"../Logo/index.c6de140f.js";import{u as k}from"../useMenu/useMenu.7f819bf5.js";const _={key:0,class:"main-sidebar-container"},j={class:"nav"},y=["title","onClick"],w=e({name:"MainSidebar"}),x=M(e({...w,setup(e){const M=a(),w=s(),{switchTo:x}=k();return(e,a)=>{const s=b,k=n("el-icon");return i(),t(f,{name:"main-sidebar"},{default:l((()=>["side"===o(M).settings.menu.menuMode||"mobile"===o(M).mode&&"single"!==o(M).settings.menu.menuMode?(i(),d("div",_,[m(h,{"show-title":!1,class:"sidebar-logo"}),u("div",j,[(i(!0),d(c,null,r(o(w).allMenus,((e,a)=>{var n,r,f;return i(),d(c,null,[e.children&&0!==e.children.length?(i(),d("div",{key:a,class:g(["item",{active:a===o(w).actived}]),title:(null==(n=e.meta)?void 0:n.title)??"[ 无标题 ]",onClick:e=>o(x)(a)},[(null==(r=e.meta)?void 0:r.icon)?(i(),t(k,{key:0},{default:l((()=>[m(s,{name:e.meta.icon},null,8,["name"])])),_:2},1024)):v("",!0),u("span",null,p((null==(f=e.meta)?void 0:f.title)??"[ 无标题 ]"),1)],10,y)):v("",!0)],64)})),256))])])):v("",!0)])),_:1})}}}),[["__scopeId","data-v-27edc889"]]);export{x as default};
