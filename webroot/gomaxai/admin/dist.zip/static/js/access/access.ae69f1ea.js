
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{ao as e,O as a}from"../main-c47e4581.js";const s={queryAccessList:a=>e.post("access/query",a),getAccess:e=>{a.warning("接口停用")},deleteAccess:e=>{a.warning("接口停用")},addAccess:e=>{a.warning("接口停用")},updateAccess:e=>{a.warning("接口停用")},updateManagerStatus:e=>{a.warning("接口停用")},resetUserPassword:e=>{a.warning("接口停用")},getSaasPage:a=>e.get("saas/page",{params:a}),deleteSaas:a=>e.post("saas/del",a),saveSaas:a=>e.post("saas/save",a),getRolePage:a=>e.get("role/page",{params:a}),deleteRole:a=>e.post("role/del",a),saveRole:a=>e.post("role/save",a)};export{s as a};
