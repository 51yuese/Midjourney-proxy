
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as e,a,z as s,r as n,j as t,o as i,I as o,g as l,e as c,c as r,b as d,f as m,m as u,Y as v,X as f,J as p,T as h,G as k,t as j,s as y,_}from"../main-c47e4581.js";import x from"../Logo/index.c6de140f.js";import g from"../Tools/index.4c4ff207.js";import{u as M}from"../useMenu/useMenu.7f819bf5.js";import"../index/index.8d1d6cf1.js";import"../access/access.ae69f1ea.js";const T={key:0},C={class:"header-container"},I={class:"main"},Y=["onClick"],b={key:1},w=e({name:"Header"}),z=_(e({...w,setup(e){const _=a(),w=s(),{switchTo:z}=M(),B=n();function G(e){B.value.scrollBy({left:(e.deltaY||e.detail)>0?50:-50})}return(e,a)=>{const s=y,n=t("el-icon");return i(),o(h,{name:"header"},{default:l((()=>["pc"===c(_).mode&&"head"===c(_).settings.menu.menuMode?(i(),r("header",T,[d("div",C,[d("div",I,[m(x),d("div",{ref_key:"navRef",ref:B,class:"nav",onWheel:u(G,["prevent"])},[(i(!0),r(v,null,f(c(w).allMenus,((e,a)=>{var t,u;return i(),r(v,{key:a},[e.children&&0!==e.children.length?(i(),r("div",{key:0,class:k(["item-container",{active:a===c(w).actived}])},[d("div",{class:"item",onClick:e=>c(z)(a)},[(null==(t=e.meta)?void 0:t.icon)?(i(),o(n,{key:0},{default:l((()=>[m(s,{name:e.meta.icon},null,8,["name"])])),_:2},1024)):p("",!0),(null==(u=e.meta)?void 0:u.title)?(i(),r("span",b,j(e.meta.title),1)):p("",!0)],8,Y)],2)):p("",!0)],64)})),128))],544)]),m(g)])])):p("",!0)])),_:1})}}}),[["__scopeId","data-v-620cc64e"]]);export{z as default};
