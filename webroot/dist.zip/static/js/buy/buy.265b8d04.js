const s="/static/svg/buy-6e704a68.svg";export{s as _};
